package snake.logic

// you can alter this file!

case class Point(x : Int, y : Int)
